package servlet;

import java.io.*;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.sql.*;

@WebServlet("/deleteStudent")
public class DeleteStudentServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int id = Integer.parseInt(request.getParameter("id"));

        try {
            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/java_student", "root", "Rehan@19");

            PreparedStatement ps = con.prepareStatement(
                "DELETE FROM JAVA_STUDENT WHERE id=?");

            ps.setInt(1, id);

            int i = ps.executeUpdate();

            // redirect back to view page
            response.sendRedirect("viewStudents");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}