package servlet;

import java.io.*;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.sql.*;
@WebServlet("/updateStudent")
public class UpdateStudentServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        int id = Integer.parseInt(request.getParameter("id"));
        String name = request.getParameter("name");
        String course = request.getParameter("course");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/java_student", "root", "Rehan@19"
            );

            PreparedStatement ps = con.prepareStatement(
                "UPDATE java_student SET name=?, course=? WHERE id=?"
            );

            ps.setString(1, name);
            ps.setString(2, course);
            ps.setInt(3, id);

            int i = ps.executeUpdate();

            if (i > 0) {
                out.println("<h2 style='color:green;text-align:center;'>✔ Student Updated Successfully</h2>");
            } else {
                out.println("<h2 style='color:red;text-align:center;'>❌ Student Not Found</h2>");
            }

        } catch (Exception e) {
            out.println("<h3>Error: " + e.getMessage() + "</h3>");
        }
    }
}